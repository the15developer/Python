import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Generate 1000 random x and y coordinates
x = np.random.randint(0, 1001, size=1000)
y = np.random.randint(0, 1001, size=1000)

# Save the coordinates to an Excel file
df = pd.DataFrame({'x': x, 'y': y})
df.to_excel('koordinatlar.xlsx', index=False)

# Read the coordinates from the Excel file
df = pd.read_excel('koordinatlar.xlsx')
x = df['x']
y = df['y']

# Define the grid size and number of colors
grid_size = 5
num_colors = 9

# Generate 25 unique colors using numpy
colors = np.random.rand(num_colors, 3)  # RGB values between 0 and 1

plt.figure(figsize=(10, 8))

for i in range(len(x)):
    grid_x = int(x[i] // (1000 / grid_size))
    grid_y = int(y[i] // (1000 / grid_size))

    # Assign a unique color to each section based on its position
    cluster = (grid_x + grid_y) % num_colors
    plt.scatter(x[i], y[i], color=colors[cluster])

plt.xlabel('X Koordinatlari')
plt.ylabel('Y Koordinatlari')

plt.grid(True)
plt.show()


