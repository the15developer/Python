import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
import os

x = np.random.randint(0, 1001, size=1000)
y = np.random.randint(0, 1001, size=1000)

df = pd.DataFrame({'x': x, 'y': y})
df.to_excel('koordinatlar.xlsx', index=False)


def generate_plot():
    df = pd.read_excel('koordinatlar.xlsx')
    x = df['x']
    y = df['y']

    grid_size = 5
    num_colors = 9

    colors = np.random.rand(num_colors, 3)

    plt.figure(figsize=(10, 8))

    for i in range(len(x)):
        grid_x = int(x[i] // (1000 / grid_size))
        grid_y = int(y[i] // (1000 / grid_size))

        cluster = (grid_x + grid_y) % num_colors
        plt.scatter(x[i], y[i], color=colors[cluster])

    plt.xlabel('X Koordinatlari')
    plt.ylabel('Y Koordinatlari')
    plt.grid(True)

    
    script_dir = os.path.dirname(os.path.abspath(__file__))

    
    image_path = os.path.join(script_dir, 'static', 'koordinatlar.png')
    #image_path2 = os.path.join(script_dir, 'templates', 'koordinatlar.png')

   
    plt.savefig(image_path, format='png')
    #plt.savefig(image_path2, format='png')
    
    
    

    return image_path




from flask import *
uyg = Flask(__name__)



@uyg.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        plot_url = generate_plot()
        #return plot_url
        return render_template('index.html')
    return render_template('index.html')

@uyg.route('/plot', methods=['GET', 'POST'])
def plot():
    if request.method == 'POST':
        image_path = generate_plot()
        return send_file(image_path, mimetype='image/png')


if __name__ == '__main__':
    uyg.run()

























