import sqlite3


def benzerlik_hesapla(metin1, metin2):

    metin1 = ''.join(c for c in metin1.lower() if c.isalnum() or c==' ')
    metin2 = ''.join(c for c in metin2.lower() if c.isalnum() or c==' ')
    
    freq1 = {}
    freq2 = {}


    for kelime in metin1.split():
        freq1[kelime] = freq1.get(kelime, 0) + 1
    for kelime in metin2.split():
        freq2[kelime] = freq2.get(kelime, 0) + 1

    dot_product = 0
    magn1 = 0
    magn2 = 0
    for kelime in set(list(freq1.keys()) + list(freq2.keys())):
        sayac1 = freq1.get(kelime, 0)
        sayac2 = freq2.get(kelime, 0)
        dot_product += sayac1 * sayac2
        magn1 += sayac1 ** 2
        magn2 += sayac2 ** 2


    magn1 = magn1 ** 0.5
    magn2 = magn2 ** 0.5
    benzerlik = dot_product / (magn1 * magn2)

    return benzerlik



metin1=input("1. metni giriniz:")


metin2=input("2. metni giriniz:")

dosya1 = open('metin1.txt','w')
dosya1.write(metin1)
dosya1.close()

dosya2 = open('metin2.txt','w')
dosya2.write(metin2)
dosya2.close()


baglanti = sqlite3.connect('veritabani1.db')
imlec = baglanti.cursor()


imlec.execute("CREATE TABLE IF NOT EXISTS metin_dosyalari(id INTEGER PRIMARY KEY AUTOINCREMENT, dosya_adi TEXT, dosya_icerigi BLOB)")

baglanti.commit()

with open('metin1.txt', 'rb') as file:
    file_content = file.read()
    imlec.execute("INSERT INTO metin_dosyalari(dosya_adi, dosya_icerigi) VALUES (?, ?)", ('metin1.txt', file_content))

with open('metin2.txt', 'rb') as file:
    file_content = file.read()
    imlec.execute("INSERT INTO metin_dosyalari(dosya_adi, dosya_icerigi) VALUES (?, ?)", ('metin2.txt', file_content))


baglanti.commit()
baglanti.close()



benzerlik = benzerlik_hesapla(metin1, metin2)

print("Benzerlik skoru: {}".format(benzerlik))

dosya = open('./benzerlik_durumu.txt','w')
dosya.write(str(benzerlik))
dosya.close()


























