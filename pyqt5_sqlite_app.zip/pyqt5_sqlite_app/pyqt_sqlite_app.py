    
from PyQt5 import QtWidgets
import sqlite3

def benzerlik_hesapla(metin1, metin2):

    metin1 = ''.join(c for c in metin1.lower() if c.isalnum() or c==' ')
    metin2 = ''.join(c for c in metin2.lower() if c.isalnum() or c==' ')
    
    freq1 = {}
    freq2 = {}


    for kelime in metin1.split():
        freq1[kelime] = freq1.get(kelime, 0) + 1
    for kelime in metin2.split():
        freq2[kelime] = freq2.get(kelime, 0) + 1

    dot_product = 0
    magn1 = 0
    magn2 = 0
    for kelime in set(list(freq1.keys()) + list(freq2.keys())):
        sayac1 = freq1.get(kelime, 0)
        sayac2 = freq2.get(kelime, 0)
        dot_product += sayac1 * sayac2
        magn1 += sayac1 ** 2
        magn2 += sayac2 ** 2


    magn1 = magn1 ** 0.5
    magn2 = magn2 ** 0.5
    benzerlik = dot_product / (magn1 * magn2)

    return benzerlik


baglanti = sqlite3.connect('veritabani2.db')
imlec = baglanti.cursor()
imlec.execute("CREATE TABLE IF NOT EXISTS kullanicilar(id INTEGER PRIMARY KEY AUTOINCREMENT, kullanici_adi TEXT, sifre TEXT)")
baglanti.commit()
baglanti.close()

uyg=QtWidgets.QApplication([]) 

pencere=QtWidgets.QWidget()
pencere.setWindowTitle("Python")
pencere.setGeometry(600,250,700,700)



pencere2=QtWidgets.QMainWindow()
pencere2.setWindowTitle("Python 2")
pencere2.setGeometry(600,250,700,700)

pencere3=QtWidgets.QWidget()
buton=QtWidgets.QPushButton(pencere3)
buton.setText("hello")


pencere4=QtWidgets.QWidget()





pencere6=QtWidgets.QWidget()
pencere6.setGeometry(600,250,700,700)
pencere6.setWindowTitle("Y algorithm")

yatay7= QtWidgets.QHBoxLayout()
yatay11= QtWidgets.QHBoxLayout()
yatay8= QtWidgets.QHBoxLayout()
yatay9= QtWidgets.QHBoxLayout()

dikey3= QtWidgets.QVBoxLayout()

dikey3.addLayout(yatay7)
dikey3.addLayout(yatay11)
dikey3.addLayout(yatay8)
dikey3.addLayout(yatay9)

giris5=QtWidgets.QLineEdit(pencere6)
giriss=QtWidgets.QLineEdit(pencere6)

def dosya_sec2():
   
    file_dialog = QtWidgets.QFileDialog()
    file_dialog.setNameFilter("All Files (*)")
    if file_dialog.exec_():
       
        selected_file = file_dialog.selectedFiles()[0]
        
        
        giris5.setText(selected_file)

def dosya_sec3():
   
    file_dialog = QtWidgets.QFileDialog()
    file_dialog.setNameFilter("All Files (*)")
    if file_dialog.exec_():
       
        selected_file = file_dialog.selectedFiles()[0]
        
        
        giriss.setText(selected_file)
        

buton6=QtWidgets.QPushButton(pencere6)
buton6.setText("DOSYA SEC")

buton6.clicked.connect(dosya_sec2)


buton9=QtWidgets.QPushButton(pencere6)
buton9.setText("DOSYA SEC")

buton9.clicked.connect(dosya_sec3)

def karsilastir2():
    try:
        content1=""
        content2=""
        file_name1 = giris5.text()
        file_name2 = giriss.text()

        with open(file_name1, 'r') as file1:
            content1=file1.read()

        
        with open(file_name2, 'r') as file2:
            content2=file2.read()
        
        print(content1)
        print(content2)
        
        etiket6.setText("2 metin arasindaki benzerlik : {}".format(benzerlik_hesapla(content1, content2)))

    except FileNotFoundError:
        
        QtWidgets.QMessageBox.critical(pencere, "Error", f"File not found: {file_name1} or {file_name2}")
    except Exception as e:
        
        QtWidgets.QMessageBox.critical(pencere, "Error", str(e))



buton7=QtWidgets.QPushButton(pencere6)
buton7.setText("KARSILASTIR")
buton7.clicked.connect(karsilastir2)

etiket6=QtWidgets.QLabel(pencere6)
etiket6.setText("HELLO")

yatay7.addWidget(giris5)
yatay7.addWidget(buton6)

yatay8.addWidget(buton7)

yatay9.addWidget(etiket6)

yatay11.addWidget(giriss)
yatay11.addWidget(buton9)

pencere6.setLayout(dikey3)





pencere5=QtWidgets.QWidget()
pencere5.setGeometry(600,250,700,700)
pencere5.setWindowTitle("X algorithm")

yatay10= QtWidgets.QHBoxLayout()
yatay11= QtWidgets.QHBoxLayout()
yatay12= QtWidgets.QHBoxLayout()
yatay13= QtWidgets.QHBoxLayout()

dikey4= QtWidgets.QVBoxLayout()

dikey4.addLayout(yatay10)
dikey4.addLayout(yatay13)
dikey4.addLayout(yatay11)
dikey4.addLayout(yatay12)


giris4=QtWidgets.QLineEdit(pencere5)
girisss=QtWidgets.QLineEdit(pencere5)

def dosya_sec():
   
    file_dialog = QtWidgets.QFileDialog()
    file_dialog.setNameFilter("All Files (*)")
    if file_dialog.exec_():
       
        selected_file = file_dialog.selectedFiles()[0]
        
        
        giris4.setText(selected_file)
        
def dosya_sec3():
   
    file_dialog = QtWidgets.QFileDialog()
    file_dialog.setNameFilter("All Files (*)")
    if file_dialog.exec_():
       
        selected_file = file_dialog.selectedFiles()[0]
        
        
        girisss.setText(selected_file)
        
buton5=QtWidgets.QPushButton(pencere5)
buton5.setText("DOSYA SEC")

buton5.clicked.connect(dosya_sec)

buton10=QtWidgets.QPushButton(pencere5)
buton10.setText("DOSYA SEC")


buton10.clicked.connect(dosya_sec3)

buton8=QtWidgets.QPushButton(pencere6)
buton8.setText("KARSILASTIR")

def karsilastir1():
    try:
        content1=""
        content2=""
        file_name1 = giris4.text()
        file_name2 = girisss.text()

        with open(file_name1, 'r') as file1:
            content1=file1.read()

        
        with open(file_name2, 'r') as file2:
            content2=file2.read()
        
        print(content1)
        print(content2)
        
        etiket7.setText("2 metin arasindaki benzerlik : {}".format(benzerlik_hesapla(content1, content2)))

    except FileNotFoundError:
        
        QtWidgets.QMessageBox.critical(pencere, "Error", f"File not found: {file_name1} or {file_name2}")
    except Exception as e:
        
        QtWidgets.QMessageBox.critical(pencere, "Error", str(e))

buton8.clicked.connect(karsilastir1)

etiket7=QtWidgets.QLabel(pencere6)
etiket7.setText("HELLO")

yatay10.addWidget(giris4)
yatay10.addWidget(buton5)

yatay11.addWidget(buton8)
yatay12.addWidget(etiket7)

yatay13.addWidget(girisss)
yatay13.addWidget(buton10)

pencere5.setLayout(dikey4)





yatay4= QtWidgets.QHBoxLayout()
yatay5= QtWidgets.QHBoxLayout()
yatay6= QtWidgets.QHBoxLayout()

dikey2= QtWidgets.QVBoxLayout()

dikey2.addLayout(yatay4)
dikey2.addLayout(yatay5)
dikey2.addLayout(yatay6)

global kullanici_adi
global sifre

kullanici_adi="hey"
sifre="hey"


pencere4.setLayout(dikey2)

etiket4=QtWidgets.QLabel(pencere4)
etiket4.setText('Sayin {} sifrenizi degistireceksiniz ! Mevcut sifreniz : {}'.format( kullanici_adi, sifre ))
yatay4.addWidget(etiket4)

etiket5=QtWidgets.QLabel(pencere4)
etiket5.setText('yeni sifre :')

giris3 =QtWidgets.QLineEdit(pencere4)

yatay5.addWidget(etiket5)
yatay5.addWidget(giris3)

buton3=QtWidgets.QPushButton(pencere4)
yatay6.addWidget(buton3)
buton3.setText('yeni sifreyi kaydet')

def sifre_kaydet():
    baglanti = sqlite3.connect('veritabani2.db')
    imlec = baglanti.cursor()
    imlec.execute("UPDATE kullanicilar SET sifre=? WHERE kullanici_adi=?", (giris3.text(), kullanici_adi))
    baglanti.commit()
    baglanti.close()
    pencere4.close()
    
    
buton3.clicked.connect(sifre_kaydet)


menubar=pencere2.menuBar()
karsilastir=menubar.addMenu("KARSILASTIR")
islemler=menubar.addMenu("ISLEMLER")
cikis=QtWidgets.QAction("CIKIS",pencere2)
menubar.addAction(cikis)

def cikis1():
    pencere2.close()
  

cikis.triggered.connect(cikis1)




def yeniPencere1():
    pencere5.show()
    
def yeniPencere2():
    pencere6.show()



sifre=islemler.addMenu("SIFRE")

degistir=QtWidgets.QAction("DEGISTIR",pencere2)
sifre.addAction(degistir)

x_algoritm=QtWidgets.QAction("Metin x algoritması kullanarak karşılaştır",pencere2)
y_algoritm=QtWidgets.QAction("Metin y algoritması kullanarak karşılaştır",pencere2)

karsilastir.addAction(x_algoritm)
karsilastir.addAction(y_algoritm)

x_algoritm.triggered.connect(yeniPencere1)
y_algoritm.triggered.connect(yeniPencere2)


def degistir1():
 print("degistir yapıldı")
 pencere4.show()
 baglanti = sqlite3.connect('veritabani2.db')
 imlec = baglanti.cursor()
 imlec.execute("SELECT kullanici_adi, sifre FROM kullanicilar WHERE kullanici_adi=?", (giris1.text(),))
 result=imlec.fetchone()
 global kullanici_adi
 global sifre
 kullanici_adi=giris1.text()
 sifre=giris2.text()
 print(kullanici_adi)
 print(sifre)
 etiket4.setText('Sayin {} sifrenizi degistireceksiniz ! Mevcut sifreniz : {}'.format( kullanici_adi, sifre ))
 baglanti.close()
 
 
 
 
 
 
degistir.triggered.connect(degistir1)

pencere2.setCentralWidget(pencere3)



buton=QtWidgets.QPushButton(pencere)
buton.setText("Kaydol")
def tikla1():
    baglanti = sqlite3.connect('veritabani2.db')
    imlec = baglanti.cursor()
    imlec.execute("SELECT kullanici_adi FROM kullanicilar WHERE kullanici_adi=?", (giris1.text(),))
    result=imlec.fetchone()
    if result:
        etiket3.setText("Kullanıcı zaten mevcuttur !")
    else:
        imlec.execute("INSERT INTO kullanicilar(kullanici_adi, sifre) VALUES (?, ?)", (giris1.text(), giris2.text()))
        baglanti.commit()
        etiket3.setText("Kullanici kaydedildi !")
    baglanti.close()
    
buton.clicked.connect(tikla1)

#buton.move(200,300)

buton2=QtWidgets.QPushButton(pencere)
buton2.setText("Giris yap")
def tikla2():
    baglanti = sqlite3.connect('veritabani2.db')
    imlec = baglanti.cursor()
    imlec.execute("SELECT kullanici_adi, sifre FROM kullanicilar WHERE kullanici_adi=?", (giris1.text(),))
    result = imlec.fetchone()
    if result and result[1] == giris2.text():
        kullanici_adi = result[0]
        sifre = result[1]
        # Do something with the retrieved values
        print(f"Kullanıcı Adı: {kullanici_adi}")
        print(f"Şifre: {sifre}")
        pencere.close()
        pencere2.show()
    else:
        # No matching record found
        etiket3.setText("Kullanıcı adı veya şifre geçersiz.")
    baglanti.close()


    
    
buton2.clicked.connect(tikla2)


buton2.move(350,300)


etiket1=QtWidgets.QLabel(pencere)
etiket1.setText("KULLANICI ADI")
etiket1.move(200,100)

etiket2=QtWidgets.QLabel(pencere)
etiket2.setText("SIFRE")
etiket2.move(200,150)

giris1=QtWidgets.QLineEdit(pencere)
giris1.move(300, 100)

giris2=QtWidgets.QLineEdit(pencere)
giris2.move(300, 150)


etiket3=QtWidgets.QLabel(pencere)
etiket3.move(250, 400)
etiket3.setText("Kullanici bilgileri giriniz")

yatay1= QtWidgets.QHBoxLayout()

yatay1.addWidget(etiket1)
yatay1.addWidget(giris1)



yatay2= QtWidgets.QHBoxLayout()

yatay2.addWidget(etiket2)
yatay2.addWidget(giris2)


yatay3= QtWidgets.QHBoxLayout()

yatay3.addWidget(buton)
yatay3.addWidget(buton2)


yatay4= QtWidgets.QHBoxLayout()

yatay4.addWidget(etiket3)

dikey= QtWidgets.QVBoxLayout()


dikey.addLayout(yatay1)
dikey.addLayout(yatay2)
dikey.addLayout(yatay3)
dikey.addLayout(yatay4)

dikey.addStretch()


pencere.setLayout(dikey)




pencere.show()

uyg.exec_()








